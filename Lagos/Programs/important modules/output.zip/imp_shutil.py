import shutil

""" important module for command prompts"""

shutil.make_archive("output", "zip")